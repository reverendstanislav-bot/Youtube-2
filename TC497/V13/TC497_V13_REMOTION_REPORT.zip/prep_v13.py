import csv,glob,json,subprocess,wave
from pathlib import Path
import numpy as np

B=Path('/home/user/tc497_v13')
ROOT=B/(B/'root.txt').read_text().strip()
GEN=next(ROOT.rglob('FINAL_62'))
ARC=ROOT/'04_DOWNLOADS'/'ARCHIVE_GREEN'
TR=B/'transcript'
EXTRA=B/'v13_generated'
PUB=B/'remotion'/'public'
SEG=B/'segments'
PUB.mkdir(parents=True,exist_ok=True); SEG.mkdir(exist_ok=True)
FPS=30; DUR=82.6

SH=[
(0.000,'INTRO_DETAIL','full','generated'),
(3.300,'INTRO_OBSERVERS','full','generated'),
(6.900,'INTRO_REVEAL','full','generated'),
(12.940,'ST-572','full','recon'),
(17.840,'WB-L06','full','recon'),
(23.060,'WB-L06','tight','recon'),
(26.460,'WD-W02','center','recon'),
(33.040,'AR-A01','full','archive'),
(36.040,'AR-A01','left','archive'),
(40.500,'WB-C04','full','recon'),
(45.352,'WB-C01','full','recon'),
(48.060,'ST-COLD','full','recon'),
(53.880,'OTTER2_COVER','full','document'),
(57.200,'ST-572','full','recon'),
(61.080,'WB-C02','tight','recon'),
(64.620,'WB-L06','tight','recon'),
(68.760,'WD-T01','full','recon'),
(71.000,'WC-Y02','center','recon'),
(74.650,'WD-W01','full','recon'),
(78.920,'ST-LAST','full','last'),
(80.840,'INTRO_REVEAL','full','title'),
(82.600,'INTRO_REVEAL','full','title')
]

# Only bridge real visual-language changes.
TD={
  1:(.10,'fade'),          # detail -> human scale
  3:(.12,'fade'),          # reveal -> established TC-497 plate
  7:(.10,'fade'),          # recon -> archive
  9:(.12,'fade'),          # archive -> recon
  12:(.12,'fade'),         # recon -> official report
  13:(.12,'fade'),         # report -> recon
  18:(.10,'fade'),         # dune -> success
  19:(.12,'fadeblack'),    # success -> aftermath
  20:(.10,'fadeblack')     # aftermath -> title
}

def asset(code):
    if code=='INTRO_DETAIL': return EXTRA/'INTRO_DETAIL.png'
    if code=='INTRO_OBSERVERS': return EXTRA/'INTRO_OBSERVERS.png'
    if code=='INTRO_REVEAL': return EXTRA/'INTRO_REVEAL.png'
    if code=='OTTER2_COVER': return EXTRA/'OTTER2_COVER.png'
    p=GEN/f'{code}.png'
    if p.exists(): return p
    xs=glob.glob(str(ARC/f'{code}__*'))
    if xs: return Path(xs[0])
    raise FileNotFoundError(code)

def vf(mode,kind):
    if kind=='document':
        return "scale=900:506:force_original_aspect_ratio=decrease,pad=960:540:(ow-iw)/2:(oh-ih)/2:color=0xC5B99F,eq=saturation=.72:contrast=1.01:brightness=-.025:gamma=.98"
    base='scale=1440:810:force_original_aspect_ratio=increase,crop=1440:810'
    if mode=='full': crop='crop=960:540:240:135'
    elif mode=='left': crop='crop=960:540:65:135'
    elif mode=='right': crop='crop=960:540:415:135'
    elif mode=='tight':
        base+=',scale=1728:972'; crop='crop=960:540:384:216'
    else: crop='crop=960:540:240:135'

    if kind=='archive':
        # V13: archive no longer flashes brighter than surrounding reconstruction.
        return base+','+crop+',hue=s=.08,eq=saturation=.72:contrast=1.015:brightness=-.055:gamma=.95,colorbalance=rs=.014:gs=.003:bs=-.012,scale=900:506,pad=960:540:30:17:color=0xC5B99F'
    if kind in ('generated','title'):
        return base+','+crop+',eq=saturation=.91:contrast=1.02:brightness=.008:gamma=1.015,colorbalance=rs=.016:gs=.003:bs=-.012'
    if kind=='last':
        return base+','+crop+',eq=saturation=.86:contrast=1.03:brightness=.003:gamma=1.01,colorbalance=rs=.016:gs=.003:bs=-.014'
    # sun-baked HIA base grade
    return base+','+crop+',eq=saturation=.90:contrast=1.025:brightness=.012:gamma=1.03,colorbalance=rs=.020:gs=.004:bs=-.015'

def render(code,mode,kind,dur,out):
    subprocess.run([
        'ffmpeg','-y','-loglevel','error','-framerate','30','-loop','1','-i',str(asset(code)),
        '-vf',vf(mode,kind)+',format=yuv420p','-frames:v',str(max(2,round(dur*FPS))),'-an',
        '-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p',str(out)
    ],check=True)

seq=[]; decisions=[]
for i,s in enumerate(SH[:-1]):
    st,c,m,k=s; en=SH[i+1][0]; n=i+1
    pin=TD.get(n-1,(0,''))[0] if n>1 else 0
    pout=TD.get(n,(0,''))[0]
    body=max(.08,en-st-pin/2-pout/2)
    bo=SEG/f'{n:03d}.mp4'; render(c,m,k,body,bo); seq.append(bo)
    decisions.append([n,st,en,c,m,k,TD.get(n,(0,'cut'))[1]])
    if n in TD and i+1<len(SH)-1:
        d,tr=TD[n]; ns=SH[i+1]
        a=SEG/f'{n:03d}a.mp4'; b=SEG/f'{n:03d}b.mp4'; x=SEG/f'{n:03d}x.mp4'
        render(c,m,k,d,a); render(ns[1],ns[2],ns[3],d,b)
        fc=f"[0:v]settb=AVTB,setpts=PTS-STARTPTS[a];[1:v]settb=AVTB,setpts=PTS-STARTPTS[b];[a][b]xfade=transition={tr}:duration={d}:offset=0[v]"
        subprocess.run([
            'ffmpeg','-y','-loglevel','error','-i',str(a),'-i',str(b),'-filter_complex',fc,
            '-map','[v]','-an','-t',str(d),'-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p',str(x)
        ],check=True)
        seq.append(x)

cl=B/'concat.txt'
cl.write_text(''.join(f"file '{p.resolve()}'\n" for p in seq))
subprocess.run(['ffmpeg','-y','-loglevel','error','-f','concat','-safe','0','-i',str(cl),'-c','copy',str(PUB/'base.mp4')],check=True)

with open(B/'V13_EDIT_DECISIONS.csv','w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(['shot','start','end','asset','framing','treatment','transition']); w.writerows(decisions)

# Stable phrase captions. Full ordered word coverage, no blackout and no karaoke.
words=[]
with open(TR/'TC497_VO_WORD_LEVEL.csv',encoding='utf-8-sig',newline='') as f:
    for r in csv.DictReader(f):
        s=float(r['start_sec']); e=float(r['end_sec'])
        if s>=DUR: break
        words.append({'s':s,'e':min(e,DUR),'w':r['word']})
phr=[]; buf=[]
for w in words:
    buf.append(w)
    punct=w['w'].endswith(('.','!','?',';',':')); comma=w['w'].endswith(',')
    if len(buf)>=6 or (punct and len(buf)>=3) or (comma and len(buf)>=5) or buf[-1]['e']-buf[0]['s']>=2.25:
        phr.append({'s':buf[0]['s'],'e':buf[-1]['e'],'words':buf}); buf=[]
if buf: phr.append({'s':buf[0]['s'],'e':buf[-1]['e'],'words':buf})
for i,p in enumerate(phr[:-1]):
    gap=phr[i+1]['s']-p['e']
    if 0<=gap<=.55: p['e']=max(p['e'],phr[i+1]['s']-.03)
(PUB/'captions.json').write_text(json.dumps(phr,ensure_ascii=False),encoding='utf-8')
subprocess.run(['cp',str(ROOT/'01_AUDIO'/'TC497_FINAL_VO.mp3'),str(PUB/'vo.mp3')],check=True)

# Controlled industrial bed + sparse physical SFX.
SR=48000; N=int(DUR*SR); t=np.arange(N,dtype=np.float32)/SR
xp=np.array([0,3.3,6.9,13,23,33,40.5,48,53.9,57.2,64.6,68.8,71,74.6,75.2,77.6,78.9,80.5,80.84,82.6])
yp=np.array([.010,.014,.022,.027,.031,.021,.027,.034,.027,.030,.034,.040,.044,.048,.016,.005,.004,.006,.038,.012])
env=np.interp(t,xp,yp).astype(np.float32)
score=(.55*np.sin(2*np.pi*46.25*t)+.18*np.sin(2*np.pi*69.375*t+.4)+.05*np.sin(2*np.pi*92.5*t+1.1)).astype(np.float32)*env
rng=np.random.default_rng(497); sfx=np.zeros(N,np.float32)
white=rng.normal(0,1,N).astype(np.float32); lp=np.zeros(N,np.float32); aa=.997
for i in range(1,N): lp[i]=aa*lp[i-1]+(1-aa)*white[i]
lp/=max(np.max(np.abs(lp)),1e-6)
air=np.interp(t,[0,2,6.9,13,33,40,61,75,82.6],[.007,.008,.004,.002,.003,.001,.002,.001,.001]).astype(np.float32)
sfx+=lp*air
for a0,b0,amp in [(0,12.9,.006),(23,26.5,.006),(68.8,75,.006)]:
    mask=((t>=a0)&(t<=b0)).astype(np.float32); sfx+=amp*mask*np.sin(2*np.pi*31*t)
def hit(tm,amp,fq,d=.30):
    i=int(tm*SR); L=min(int(d*SR),N-i); tt=np.arange(L,dtype=np.float32)/SR
    sfx[i:i+L]+=amp*(np.sin(2*np.pi*fq*tt)+.18*np.sin(2*np.pi*fq*2.1*tt))*np.exp(-tt*11)
for h in [(3.30,.022,72),(6.90,.055,45),(12.94,.040,48),(23.06,.030,73),(33.04,.018,110),(53.88,.016,100),(68.76,.028,55),(74.65,.055,46),(78.92,.070,39),(80.84,.040,52)]: hit(*h)
for name,arr in [('score.wav',score),('sfx.wav',sfx)]:
    pcm=(np.clip(np.tanh(arr*1.04),-.75,.75)*32767).astype(np.int16)
    with wave.open(str(PUB/name),'wb') as wf:
        wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(SR); wf.writeframes(pcm.tobytes())

print('V13_PREP_DONE',len(phr),len(words))
